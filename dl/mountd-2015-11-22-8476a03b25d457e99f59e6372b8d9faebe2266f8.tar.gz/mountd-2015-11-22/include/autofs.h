#ifndef _AUTOFS_H__
#define _AUTOFS_H__

int autofs_loop(void);
pid_t autofs_safe_fork(void);

#endif
